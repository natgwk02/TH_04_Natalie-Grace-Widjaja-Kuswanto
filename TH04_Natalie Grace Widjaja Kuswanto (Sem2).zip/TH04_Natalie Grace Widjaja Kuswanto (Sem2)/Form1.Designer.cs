﻿namespace TH04_Natalie_Grace_Widjaja_Kuswanto__Sem2_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_soccerteamlist = new System.Windows.Forms.Label();
            this.lb_addingteam = new System.Windows.Forms.Label();
            this.lb_addingplayers = new System.Windows.Forms.Label();
            this.lb_choosecountry = new System.Windows.Forms.Label();
            this.lb_chooseteam = new System.Windows.Forms.Label();
            this.lb_teamname = new System.Windows.Forms.Label();
            this.lb_teamcountry = new System.Windows.Forms.Label();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.lb_playername = new System.Windows.Forms.Label();
            this.lb_playernumber = new System.Windows.Forms.Label();
            this.lb_playerposition = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_playerpos = new System.Windows.Forms.ComboBox();
            this.lbox1_players = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.tb_teamname = new System.Windows.Forms.TextBox();
            this.tb_teamcountry = new System.Windows.Forms.TextBox();
            this.tb_teamcity = new System.Windows.Forms.TextBox();
            this.tb_playername = new System.Windows.Forms.TextBox();
            this.tb_playernumber = new System.Windows.Forms.TextBox();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_addplayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_soccerteamlist
            // 
            this.lb_soccerteamlist.AutoSize = true;
            this.lb_soccerteamlist.Location = new System.Drawing.Point(12, 60);
            this.lb_soccerteamlist.Name = "lb_soccerteamlist";
            this.lb_soccerteamlist.Size = new System.Drawing.Size(90, 13);
            this.lb_soccerteamlist.TabIndex = 0;
            this.lb_soccerteamlist.Text = "Soccer Team List";
            // 
            // lb_addingteam
            // 
            this.lb_addingteam.AutoSize = true;
            this.lb_addingteam.Location = new System.Drawing.Point(299, 60);
            this.lb_addingteam.Name = "lb_addingteam";
            this.lb_addingteam.Size = new System.Drawing.Size(70, 13);
            this.lb_addingteam.TabIndex = 1;
            this.lb_addingteam.Text = "Adding Team";
            // 
            // lb_addingplayers
            // 
            this.lb_addingplayers.AutoSize = true;
            this.lb_addingplayers.Location = new System.Drawing.Point(519, 60);
            this.lb_addingplayers.Name = "lb_addingplayers";
            this.lb_addingplayers.Size = new System.Drawing.Size(77, 13);
            this.lb_addingplayers.TabIndex = 2;
            this.lb_addingplayers.Text = "Adding Players";
            // 
            // lb_choosecountry
            // 
            this.lb_choosecountry.AutoSize = true;
            this.lb_choosecountry.Location = new System.Drawing.Point(12, 92);
            this.lb_choosecountry.Name = "lb_choosecountry";
            this.lb_choosecountry.Size = new System.Drawing.Size(85, 13);
            this.lb_choosecountry.TabIndex = 3;
            this.lb_choosecountry.Text = "Choose Country:";
            // 
            // lb_chooseteam
            // 
            this.lb_chooseteam.AutoSize = true;
            this.lb_chooseteam.Location = new System.Drawing.Point(12, 128);
            this.lb_chooseteam.Name = "lb_chooseteam";
            this.lb_chooseteam.Size = new System.Drawing.Size(76, 13);
            this.lb_chooseteam.TabIndex = 7;
            this.lb_chooseteam.Text = "Choose Team:";
            // 
            // lb_teamname
            // 
            this.lb_teamname.AutoSize = true;
            this.lb_teamname.Location = new System.Drawing.Point(224, 87);
            this.lb_teamname.Name = "lb_teamname";
            this.lb_teamname.Size = new System.Drawing.Size(68, 13);
            this.lb_teamname.TabIndex = 6;
            this.lb_teamname.Text = "Team Name:";
            // 
            // lb_teamcountry
            // 
            this.lb_teamcountry.AutoSize = true;
            this.lb_teamcountry.Location = new System.Drawing.Point(224, 119);
            this.lb_teamcountry.Name = "lb_teamcountry";
            this.lb_teamcountry.Size = new System.Drawing.Size(76, 13);
            this.lb_teamcountry.TabIndex = 5;
            this.lb_teamcountry.Text = "Team Country:";
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Location = new System.Drawing.Point(224, 150);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(57, 13);
            this.lb_teamcity.TabIndex = 4;
            this.lb_teamcity.Text = "Team City:";
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Location = new System.Drawing.Point(430, 87);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(70, 13);
            this.lb_playername.TabIndex = 11;
            this.lb_playername.Text = "Player Name:";
            // 
            // lb_playernumber
            // 
            this.lb_playernumber.AutoSize = true;
            this.lb_playernumber.Location = new System.Drawing.Point(430, 119);
            this.lb_playernumber.Name = "lb_playernumber";
            this.lb_playernumber.Size = new System.Drawing.Size(79, 13);
            this.lb_playernumber.TabIndex = 10;
            this.lb_playernumber.Text = "Player Number:";
            // 
            // lb_playerposition
            // 
            this.lb_playerposition.AutoSize = true;
            this.lb_playerposition.Location = new System.Drawing.Point(430, 150);
            this.lb_playerposition.Name = "lb_playerposition";
            this.lb_playerposition.Size = new System.Drawing.Size(79, 13);
            this.lb_playerposition.TabIndex = 9;
            this.lb_playerposition.Text = "Player Position:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(213, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 13);
            this.label12.TabIndex = 8;
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(97, 89);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(121, 21);
            this.cb_country.TabIndex = 12;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(97, 128);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(121, 21);
            this.cb_team.TabIndex = 13;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_playerpos
            // 
            this.cb_playerpos.FormattingEnabled = true;
            this.cb_playerpos.Location = new System.Drawing.Point(522, 147);
            this.cb_playerpos.Name = "cb_playerpos";
            this.cb_playerpos.Size = new System.Drawing.Size(121, 21);
            this.cb_playerpos.TabIndex = 14;
            // 
            // lbox1_players
            // 
            this.lbox1_players.FormattingEnabled = true;
            this.lbox1_players.Location = new System.Drawing.Point(31, 193);
            this.lbox1_players.Name = "lbox1_players";
            this.lbox1_players.Size = new System.Drawing.Size(160, 108);
            this.lbox1_players.TabIndex = 15;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(31, 307);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(75, 23);
            this.btn_remove.TabIndex = 16;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // tb_teamname
            // 
            this.tb_teamname.Location = new System.Drawing.Point(302, 85);
            this.tb_teamname.Name = "tb_teamname";
            this.tb_teamname.Size = new System.Drawing.Size(100, 20);
            this.tb_teamname.TabIndex = 17;
            // 
            // tb_teamcountry
            // 
            this.tb_teamcountry.Location = new System.Drawing.Point(302, 116);
            this.tb_teamcountry.Name = "tb_teamcountry";
            this.tb_teamcountry.Size = new System.Drawing.Size(100, 20);
            this.tb_teamcountry.TabIndex = 18;
            // 
            // tb_teamcity
            // 
            this.tb_teamcity.Location = new System.Drawing.Point(302, 147);
            this.tb_teamcity.Name = "tb_teamcity";
            this.tb_teamcity.Size = new System.Drawing.Size(100, 20);
            this.tb_teamcity.TabIndex = 19;
            // 
            // tb_playername
            // 
            this.tb_playername.Location = new System.Drawing.Point(522, 85);
            this.tb_playername.Name = "tb_playername";
            this.tb_playername.Size = new System.Drawing.Size(100, 20);
            this.tb_playername.TabIndex = 20;
            // 
            // tb_playernumber
            // 
            this.tb_playernumber.Location = new System.Drawing.Point(522, 116);
            this.tb_playernumber.Name = "tb_playernumber";
            this.tb_playernumber.Size = new System.Drawing.Size(100, 20);
            this.tb_playernumber.TabIndex = 21;
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(314, 183);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(75, 23);
            this.btn_addteam.TabIndex = 22;
            this.btn_addteam.Text = "Add";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_addplayer
            // 
            this.btn_addplayer.Location = new System.Drawing.Point(547, 183);
            this.btn_addplayer.Name = "btn_addplayer";
            this.btn_addplayer.Size = new System.Drawing.Size(75, 23);
            this.btn_addplayer.TabIndex = 23;
            this.btn_addplayer.Text = "Add";
            this.btn_addplayer.UseVisualStyleBackColor = true;
            this.btn_addplayer.Click += new System.EventHandler(this.btn_addplayer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_addplayer);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.tb_playernumber);
            this.Controls.Add(this.tb_playername);
            this.Controls.Add(this.tb_teamcity);
            this.Controls.Add(this.tb_teamcountry);
            this.Controls.Add(this.tb_teamname);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.lbox1_players);
            this.Controls.Add(this.cb_playerpos);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_playernumber);
            this.Controls.Add(this.lb_playerposition);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lb_chooseteam);
            this.Controls.Add(this.lb_teamname);
            this.Controls.Add(this.lb_teamcountry);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.lb_choosecountry);
            this.Controls.Add(this.lb_addingplayers);
            this.Controls.Add(this.lb_addingteam);
            this.Controls.Add(this.lb_soccerteamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_soccerteamlist;
        private System.Windows.Forms.Label lb_addingteam;
        private System.Windows.Forms.Label lb_addingplayers;
        private System.Windows.Forms.Label lb_choosecountry;
        private System.Windows.Forms.Label lb_chooseteam;
        private System.Windows.Forms.Label lb_teamname;
        private System.Windows.Forms.Label lb_teamcountry;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.Label lb_playernumber;
        private System.Windows.Forms.Label lb_playerposition;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_playerpos;
        private System.Windows.Forms.ListBox lbox1_players;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.TextBox tb_teamname;
        private System.Windows.Forms.TextBox tb_teamcountry;
        private System.Windows.Forms.TextBox tb_teamcity;
        private System.Windows.Forms.TextBox tb_playername;
        private System.Windows.Forms.TextBox tb_playernumber;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_addplayer;
    }
}

