﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Natalie_Grace_Widjaja_Kuswanto__Sem2_
{
    internal class MU
    {
    }
}
