﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Natalie_Grace_Widjaja_Kuswanto__Sem2_
{
    internal class Team
    {
        public List<Player> player = new List<Player>();
        public string teamname;
        public string teamcountry;
        public string teamcity;
        public Team (string teamname, string teamcountry, string teamcity)
        {
            this.teamname = teamname;
            this.teamcountry = teamcountry;
            this.teamcity = teamcity;
        }
       
    }
}
