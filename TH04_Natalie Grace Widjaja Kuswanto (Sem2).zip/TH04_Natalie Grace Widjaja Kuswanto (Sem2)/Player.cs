﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Natalie_Grace_Widjaja_Kuswanto__Sem2_
{
    internal class Player
    {
        public string playername;
        public string playernumber;
        public string playerpos;
        public Player(string playername, string playernumber, string playerpos)
        {
            this.playername = playername;
            this.playernumber = playernumber;
            this.playerpos = playerpos;
        }
    }
}
