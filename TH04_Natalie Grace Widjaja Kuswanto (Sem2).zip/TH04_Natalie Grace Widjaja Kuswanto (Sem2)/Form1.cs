﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Natalie_Grace_Widjaja_Kuswanto__Sem2_
{
    public partial class Form1 : Form
    {
        List<Team> jumlahteam = new List<Team>();
        string teamyangdipakai ="";

        public Form1()
        {        
            InitializeComponent();       
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
           cb_team.Items.Clear();
           cb_team.Text = ""; // ngeclear text waktu ganti negara
           for (int i = 0; i <  jumlahteam.Count; i++)
           {
                if (jumlahteam[i].teamcountry == cb_country.Text)
                { 
                    cb_team.Items.Add(jumlahteam[i].teamname);
                }
           }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Team team = new Team("Manchester United","England", "London");
            jumlahteam.Add(team);
            Team team2 = new Team("Chelsea", "England", "Liverpool");
            jumlahteam.Add(team2);
            Team team3 = new Team("Bayem Munich", "Germany", "Berlin");
            jumlahteam.Add(team3);

            Player player1 = new Player("David De Gea", "01", "GK");
            team.player.Add(player1);
            Player player1_2 = new Player("Victor Lindelof", "02", "DF");
            team.player.Add(player1_2);
            Player player1_3 = new Player("Phil Jones", "04", "DF");
            team.player.Add(player1_3);
            Player player1_4 = new Player("Harry Maguire", "05", "DF");
            team.player.Add(player1_4);
            Player player1_5 = new Player("Lisandro Martinez", "06", "DF");
            team.player.Add(player1_5);
            Player player1_6 = new Player("Bruno Fernandez", "08", "MF");
            team.player.Add(player1_6);
            Player player1_7 = new Player("Anthony Martial", "09", "FW");
            team.player.Add(player1_7);
            Player player1_8 = new Player("Marcus Rashford", "10", "FW");
            team.player.Add(player1_8);
            Player player1_9 = new Player("Tyrell Malacia", "12", "DF");
            team.player.Add(player1_9);
            Player player1_10 = new Player("Christian Eriksen", "14", "MF");
            team.player.Add(player1_10);
            Player player1_11 = new Player("Casemiro", "18", "MF");
            team.player.Add(player1_11);

            Player player2_1 = new Player("Kepa Arrizabalaga", "01", "GK");
            team2.player.Add(player2_1);
            Player player2_2 = new Player("Benoit Badiashile", "04", "DF");
            team2.player.Add(player2_2);
            Player player2_3 = new Player("Enzo Fernandez", "05", "MF");
            team2.player.Add(player2_3);
            Player player2_4 = new Player("Thiago Silva", "06", "DF");
            team2.player.Add(player2_4);
            Player player2_5 = new Player("N'Golo Kante", "07", "MF");
            team2.player.Add(player2_5);
            Player player2_6 = new Player("Mateo Kovacic", "08", "MF");
            team2.player.Add(player2_6);
            Player player2_7 = new Player("Pierre-Emerick Aubameyang", "09", "FW");
            team2.player.Add(player2_7);
            Player player2_8 = new Player("Christian Pulisic", "10", "MF");
            team2.player.Add(player2_8);
            Player player2_9 = new Player("Joao Felix", "11", "FW");
            team2.player.Add(player2_9);
            Player player2_10 = new Player("Ruben Loftus-Cheek", "12", "MF");
            team2.player.Add(player2_10);
            Player player2_11 = new Player("Raheem Sterling", "17", "MF");
            team2.player.Add(player2_11);

            Player player3_1 = new Player("Manuel Neuer", "01", "GK");
            team3.player.Add(player3_1);
            Player player3_2 = new Player("Dayot Uparnecano", "02", "DF");
            team3.player.Add(player3_2);
            Player player3_3 = new Player("Matthjis de Ligt", "04", "DF");
            team3.player.Add(player3_3);
            Player player3_4 = new Player("Benjamin Pavard", "05", "DF");
            team3.player.Add(player3_4);
            Player player3_5 = new Player("Joshua Kimmich", "06", "MF");
            team3.player.Add(player3_5);
            Player player3_6 = new Player("Serge Gnabry", "07", "FW");
            team3.player.Add(player3_6);
            Player player3_7 = new Player("Leon Goretzka", "08", "MF");
            team3.player.Add(player3_7);
            Player player3_8 = new Player("Leroy Sane", "10", "FW");
            team3.player.Add(player3_8);
            Player player3_9 = new Player("Paul Wanner", "14", "MF");
            team3.player.Add(player3_9);
            Player player3_10 = new Player("Lucas Hernandez", "21", "DF");
            team3.player.Add(player3_10);
            Player player3_11 = new Player("Thomas Muller", "25", "FW");
            team3.player.Add(player3_11);

            foreach (Team team0 in jumlahteam)
            {
                if (!cb_country.Items.Contains(team0.teamcountry))
                {
                    cb_country.Items.Add(team0.teamcountry);
                }  
            }
            cb_playerpos.Items.Add("GK");
            cb_playerpos.Items.Add("MF");
            cb_playerpos.Items.Add("FW");
            cb_playerpos.Items.Add("DF");
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            teamyangdipakai = cb_team.Text;
            lbox1_players.Items.Clear();
            
            for (int i = 0; i < jumlahteam.Count; i++)
            {
                if (jumlahteam[i].teamname == teamyangdipakai)
                {
                    for(int j =0; j < jumlahteam[i].player.Count; j++)
                    {
                        lbox1_players.Items.Add("(" + jumlahteam[i].player[j].playernumber + ") " + jumlahteam[i].player[j].playername + ", "+ jumlahteam[i].player[j].playerpos);
                    }
                }
            }
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            string teamname = tb_teamname.Text;
            string teamcountry = tb_teamcountry.Text;
            string teamcity = tb_teamcity.Text;
            cb_country.Items.Clear();
            cb_team.Items.Clear();
            bool jalan = true;
            if (teamname.Length == 0 || teamcountry.Length == 0 || teamcity.Length == 0)
            {
                MessageBox.Show("All fields need to be filled");
                return;
            }

            for (int i=0; i < jumlahteam.Count; i ++)
            {
                if (jumlahteam[i].teamname == teamname && jumlahteam[i].teamcountry == teamcountry)
                {
                    jalan = false;
                    break;
                }
                else
                {
                    jalan = true;
                }
            }
           if (jalan == true)
           {
                Team team = new Team(teamname, teamcountry, teamcity);
                jumlahteam.Add(team);
              
                foreach (Team team0 in jumlahteam)
                {
                    if (!cb_country.Items.Contains(team0.teamcountry))
                    {
                        cb_country.Items.Add(team0.teamcountry);
                    }
                }
                tb_teamname.Text = "";
                tb_teamcountry.Text = "";
                tb_teamcity.Text = "";
            }
           else
           {
                MessageBox.Show("Nama team tidak boleh sama");

           }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (lbox1_players.Items.Count > 11)
            {
                int selectedIndex = lbox1_players.SelectedIndex;
                if (selectedIndex != -1)
                {
                    lbox1_players.Items.RemoveAt(selectedIndex);
                }
            }
            else
            {
                MessageBox.Show("Unable to remove players if players less than equal 11");
            }     
        }

        private void btn_addplayer_Click(object sender, EventArgs e)
        {
            string playername = tb_playername.Text;
            string playernumber = tb_playernumber.Text;
            string playerpos = cb_playerpos.Text;

            bool nomornyasama = false;
            int nomorplayer;
            if (playername.Length == 0 || playernumber.Length == 0 || playerpos.Length == 0)
            {
                MessageBox.Show("All fields need to be filled");
                return;
            }

            if (!int.TryParse(playernumber, out nomorplayer))
            {
                MessageBox.Show("Player number must be a number");
                return;
            }

            foreach (Team team in jumlahteam)
            {
                if (team.teamname == teamyangdipakai)
                {
                    foreach (Player player in team.player)
                    {
                        if (player.playernumber == playernumber)
                        {
                            nomornyasama = true;
                            break;
                        }
                    }
                    if (nomornyasama)
                        break;
                }
            }

            if (nomornyasama)
            {
                MessageBox.Show("Player with same number is found");
            }
            else
            {
                foreach (Team team in jumlahteam)
                {
                    if (team.teamname == teamyangdipakai)
                    {
                        Player newPlayer = new Player(playername, playernumber, playerpos);
                        team.player.Add(newPlayer);
                        lbox1_players.Items.Add("(" + playernumber + ") " + playername + ", " + playerpos);
                        break;
                    }
                }
            }
           
        }
    }
}
